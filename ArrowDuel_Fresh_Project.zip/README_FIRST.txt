ARROW DUEL — EASY UPLOAD PACKAGE

This is the Android project source, not the APK.
To build the APK with GitHub Actions:
1. Upload the CONTENTS of this folder to your GitHub repository (not this ZIP file).
2. Keep the hidden .github/workflows/build-apk.yml file.
3. In GitHub, open the repository > Actions > Build Arrow Duel APK > Run workflow.
4. When complete, open the workflow run and download the ArrowDuel-APK artifact.
5. Extract the downloaded artifact ZIP to get app-debug.apk.
