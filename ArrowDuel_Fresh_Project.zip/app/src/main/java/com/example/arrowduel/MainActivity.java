package com.example.arrowduel;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.util.Random;

public class MainActivity extends Activity {
    int coins = 1000, bet = 50, angle = 45, prediction = 40;
    TextView info;
    GameView game;
    boolean twoPlayers = false;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,18,18,18);
        root.setBackgroundColor(Color.rgb(238,242,247));
        TextView title = new TextView(this);
        title.setText("🏹 ARROW DUEL");
        title.setTextSize(26); title.setTextColor(Color.rgb(25,40,65));
        title.setGravity(Gravity.CENTER); root.addView(title);
        info = new TextView(this); info.setTextSize(16); info.setPadding(4,12,4,12);
        root.addView(info);
        LinearLayout modes = new LinearLayout(this);
        Button cpu = new Button(this); cpu.setText("Vs Computer");
        Button local = new Button(this); local.setText("2 Players");
        modes.addView(cpu,new LinearLayout.LayoutParams(0, -2,1));
        modes.addView(local,new LinearLayout.LayoutParams(0, -2,1));
        root.addView(modes);
        cpu.setOnClickListener(v->{twoPlayers=false; updateInfo("Mode: vs Computer");});
        local.setOnClickListener(v->{twoPlayers=true; updateInfo("Mode: 2 Players");});
        game = new GameView();
        root.addView(game,new LinearLayout.LayoutParams(-1,0,1));
        TextView hint = new TextView(this);
        hint.setText("Drag your finger on the field to aim. Predict the landing angle, then shoot.");
        hint.setTextSize(14); root.addView(hint);
        TextView predLabel = new TextView(this); predLabel.setText("Your predicted angle: 40°");
        root.addView(predLabel);
        SeekBar pred = new SeekBar(this); pred.setMax(90); pred.setProgress(40); root.addView(pred);
        pred.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean u){prediction=p;predLabel.setText("Your predicted angle: "+p+"°");}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        });
        Button shoot = new Button(this); shoot.setText("SHOOT — 50 VIRTUAL COINS");
        root.addView(shoot);
        shoot.setOnClickListener(v->{
            if(coins<bet){updateInfo("Not enough coins. Restart the app to reset the demo balance.");return;}
            coins-=bet;
            int landing = Math.max(0,Math.min(90,angle + new Random().nextInt(21)-10));
            int diff=Math.abs(prediction-landing);
            String result;
            if(diff<=5){coins+=bet*3/2;result="Bullseye prediction! You won "+(bet*3/2)+" coins.";}
            else {coins+=bet*98/100;result="Missed. 2% fee applied to the stake.";}
            updateInfo(result+"\nLanding angle: "+landing+"°");
            game.invalidate();
        });
        setContentView(root); updateInfo("Mode: vs Computer");
    }
    void updateInfo(String msg){ if(info!=null)info.setText("Virtual coins: "+coins+"\n"+msg); }
    class GameView extends View {
        Paint p=new Paint(3); float downX,downY;
        GameView(){super(MainActivity.this);setMinimumHeight(360);}
        protected void onDraw(Canvas c){
            super.onDraw(c); int w=getWidth(),h=getHeight();
            c.drawColor(Color.rgb(214,231,210));
            p.setColor(Color.rgb(100,145,85)); c.drawRect(0,h*.72f,w,h,p);
            p.setColor(Color.rgb(60,75,55)); p.setTextSize(22); c.drawText("DRAG TO AIM",20,35,p);
            float x=70,y=h*.72f; double r=Math.toRadians(angle);
            p.setColor(Color.DKGRAY);p.setStrokeWidth(5);
            c.drawLine(x,y,x+(float)Math.cos(r)*115,y-(float)Math.sin(r)*115,p);
            p.setColor(Color.rgb(160,65,35));p.setStrokeWidth(3);
            c.drawLine(x+(float)Math.cos(r)*115,y-(float)Math.sin(r)*115,
                x+(float)Math.cos(r)*135,y-(float)Math.sin(r)*135,p);
            p.setColor(Color.BLACK);p.setTextSize(18);c.drawText("Aim: "+angle+"°",20,h-20,p);
        }
        public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE || e.getAction()==MotionEvent.ACTION_UP){
                float dx=e.getX()-70, dy=(getHeight()*.72f)-e.getY();
                angle=(int)Math.max(0,Math.min(90,Math.toDegrees(Math.atan2(Math.max(0,dy),Math.max(1,dx)))));
                invalidate();return true;
            } return true;
        }
    }
}
